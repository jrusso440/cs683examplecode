package edu.bu.myserviceasynexample.Service

import android.annotation.TargetApi
import android.app.job.JobService
import android.app.job.JobParameters
import android.util.Log
import android.widget.Toast

class MyJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val id = params.extras.getInt("id")
        Toast.makeText(this, "Job $id is scheduled", Toast.LENGTH_LONG).show()
         // do some work here
        //mimic a background work
        Thread.sleep(10000L)
        Log.d("Jobservice", "onStart: Thread id " + Thread.currentThread().id)
        return false
    }

    override fun onStopJob(params: JobParameters): Boolean {
        Toast.makeText(this, "Job is canceled", Toast.LENGTH_LONG).show()
        return false
    }
}