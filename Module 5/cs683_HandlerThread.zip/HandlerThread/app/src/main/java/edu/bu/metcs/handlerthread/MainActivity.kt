package edu.bu.metcs.handlerthread

import android.os.*
import edu.bu.metcs.handlerthread.LongOperation.run
import androidx.appcompat.app.AppCompatActivity
import android.widget.EditText
import android.widget.TextView
import edu.bu.metcs.handlerthread.R
import android.util.Log
import android.view.View
import android.widget.Toast
import edu.bu.metcs.handlerthread.LongOperation
import edu.bu.metcs.handlerthread.databinding.ActivityMainBinding
import java.lang.Exception

class MainActivity : AppCompatActivity() {
    private lateinit var mainHandler: Handler
    private lateinit var threadHandler: Handler
    private lateinit var mHandlerThread: HandlerThread

    private lateinit var binding:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.displayText.setText("")

        // create a handler for the main thread
        mainHandler = Handler()

        // create a handler thread mHandlerThread
        mHandlerThread = HandlerThread("background handler thread")
        // start mHandlerThread  by calling its start() method
        mHandlerThread!!.start()

        // Create a threadHandler that is associated with the mHandlerThread,
        threadHandler = Handler(mHandlerThread!!.looper, Handler.Callback{msg->
           // run the long operation, and send back the result to the main thread
            val i = LongOperation.run(msg.getData().getLong("delay"))
            val threadid = Thread.currentThread().id
            mainHandler!!.post{
                binding.displayText.text = "Thread " +
                        + threadid +
                        " Done : i =" + i
            }
            // After 2 seconds, the output is cleared
            mainHandler!!.postDelayed({ binding.displayText!!.text = "" },
                2000)
            true
        })
    }

    // called when clicking the display button
    fun display(v: View?) {
        // get the delay value from the editview
        val delayStr = binding.delayTime!!.text.toString()
        val delay = if (delayStr!="") delayStr.toLong() else 0

        binding.displayText!!.text = """execute 
            for (i = 0; i <${delay * 100000000}; i++) """

        val bundle = Bundle().apply {
            putLong("delay", delay)
        }
        // send the delay to the handler thread
        threadHandler!!.sendMessage(Message.obtain().apply{
            setData(bundle)})
    }
}