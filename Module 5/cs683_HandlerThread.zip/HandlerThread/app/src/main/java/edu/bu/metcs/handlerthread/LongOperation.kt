package edu.bu.metcs.handlerthread

import android.util.Log

object LongOperation {
    private const val TAG = "Long Operation"
    @JvmStatic
    fun run(threadDelay: Long): Long {
        Log.d(TAG, " delay $threadDelay")
        var i:Long = 0
        for (i in 0 .. threadDelay * 100000000);
        Log.d(TAG, " delay $threadDelay")
        return i
    }
}