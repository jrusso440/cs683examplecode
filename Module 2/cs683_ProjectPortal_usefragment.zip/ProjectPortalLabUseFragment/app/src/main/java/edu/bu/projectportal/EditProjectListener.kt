package edu.bu.projectportal

interface EditProjectListener {
    fun editProj()
    fun editProjDone()
}