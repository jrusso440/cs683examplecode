package edu.bu.projectportal.datalayer

data class LoggedInUser(
    val userId: String,
    val displayName: String,
    val email:String
)
